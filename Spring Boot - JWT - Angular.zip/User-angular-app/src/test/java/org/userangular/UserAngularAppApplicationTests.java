package org.userangular;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserAngularAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
