import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UserserviceService } from '../service/userservice.service';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-user',
  imports: [FormsModule,CommonModule

  ],
  templateUrl: './user.component.html',
  styleUrl: './user.component.css',
  standalone:true
})
export class UserComponent {
  user = {
    username: '',
    password: ''
  };

  constructor(private userService: UserserviceService) {}

  onClickSubmit(formData: any) {
    this.userService.login(formData.username, formData.password).subscribe({
      next: (res) => {
        console.log('Login successful:', res);
        localStorage.setItem('token', res.token);
        localStorage.setItem('role', res.role);
      },
      error: (err) => {
        console.error('Login failed:', err);
        alert('Invalid credentials');
      }
    });
  }

  loginAdmin(){
    this.userService.getAdminData().subscribe({
      next: (res) => console.log("Admin data:", res),
      error: (err) => console.error("Unauthorized or error:", err)
    });
    
  }
}
