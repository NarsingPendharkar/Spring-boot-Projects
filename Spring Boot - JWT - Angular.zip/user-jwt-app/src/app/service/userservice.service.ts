import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class UserserviceService {

  private apiUrl = 'http://localhost:8282/api/auth/login'; // ✅ match the actual backend port

  constructor(private http: HttpClient) {}

  login(username: string, password: string): Observable<any> {
    return this.http.post(this.apiUrl, { username, password });
  }

  getAdminData(): Observable<any> {
    return this.http.get('http://localhost:8282/api/auth/admin/home', { responseType: 'text' });
  }

}
