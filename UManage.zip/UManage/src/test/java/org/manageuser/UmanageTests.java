package org.manageuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UmanageTests {

	@Test
	void contextLoads() {
	}

}
